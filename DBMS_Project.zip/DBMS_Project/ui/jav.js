XXX
function sum(YYY){
    return a+b;
}
console.log(sum(10));